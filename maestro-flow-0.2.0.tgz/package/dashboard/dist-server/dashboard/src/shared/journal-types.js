// ---------------------------------------------------------------------------
// Execution Journal types — append-only event log for crash recovery
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=journal-types.js.map