// ---------------------------------------------------------------------------
// Wave execution types — CSV-wave-inspired parallel task execution
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=wave-types.js.map