// ---------------------------------------------------------------------------
// Extension types -- supervisor extension lifecycle and metadata
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=extension-types.js.map