import { readFile, readdir, stat, lstat } from 'node:fs/promises';
import { basename, dirname, extname, join, relative, resolve, sep } from 'node:path';
import { toForwardSlash } from '../../shared/utils.js';
import { parseFrontmatter } from './frontmatter-util.js';
import { loadVirtualEntries } from './virtual-wiki-adapters.js';
import { buildGraph } from './graph-analysis.js';
import { buildInvertedIndex, searchBM25 } from './search.js';
/**
 * WikiIndexer: single source of truth for the unified wiki index.
 *
 * Responsibilities:
 *   1. Walk `.workflow/` for known wiki sources.
 *   2. Parse frontmatter + infer missing fields.
 *   3. Adapt JSONL rows as virtual entries.
 *   4. Build backlinks from `related: [[id]]` frontmatter.
 *   5. Cache index + memoized graph + BM25 index.
 *   6. Single-flight rebuild with invalidate().
 */
export class WikiIndexer {
    workflowRoot;
    cache = null;
    graphCache = null;
    searchCache = null;
    inflight = null;
    constructor(config) {
        this.workflowRoot = resolve(config.workflowRoot);
    }
    getWorkflowRoot() {
        return this.workflowRoot;
    }
    async get() {
        if (this.cache)
            return this.cache;
        return this.rebuild();
    }
    async rebuild() {
        if (this.inflight)
            return this.inflight;
        this.inflight = (async () => {
            const fileEntries = await this.scanFiles();
            const virtualEntries = await this.scanVirtual();
            const entries = [...fileEntries, ...virtualEntries];
            // Stable collision suffix
            const seen = new Map();
            for (const d of entries) {
                const n = seen.get(d.id) ?? 0;
                if (n > 0) {
                    // eslint-disable-next-line no-console
                    console.warn(`[wiki-indexer] id collision '${d.id}' — suffixing`);
                    d.id = `${d.id}-${n + 1}`;
                }
                seen.set(d.id, n + 1);
            }
            const byId = {};
            const byType = {
                project: [],
                roadmap: [],
                spec: [],
                phase: [],
                issue: [],
                lesson: [],
                memory: [],
                note: [],
            };
            for (const d of entries) {
                byId[d.id] = d;
                byType[d.type].push(d);
            }
            const backlinks = this.buildBacklinks(entries, byId);
            const index = {
                entries,
                byId,
                byType,
                backlinks,
                generatedAt: Date.now(),
            };
            this.cache = index;
            this.graphCache = null;
            this.searchCache = null;
            return index;
        })();
        try {
            return await this.inflight;
        }
        finally {
            this.inflight = null;
        }
    }
    invalidate(_changedAbsPath) {
        this.cache = null;
        this.graphCache = null;
        this.searchCache = null;
    }
    async query(filters) {
        const index = await this.get();
        // Non-q filters first (cheap), then BM25 if q is present.
        const base = filterEntries(index.entries, { ...filters, q: undefined });
        if (!filters.q || !filters.q.trim())
            return base;
        const bm25 = await this.getSearchIndex();
        const ranked = searchBM25(bm25, filters.q);
        const allowed = new Set(base.map((d) => d.id));
        const out = [];
        for (const r of ranked) {
            if (allowed.has(r.docId) && index.byId[r.docId]) {
                out.push(index.byId[r.docId]);
            }
        }
        return out;
    }
    async groups(filters) {
        const source = filters ? await this.query(filters) : (await this.get()).entries;
        const out = {
            project: [],
            roadmap: [],
            spec: [],
            phase: [],
            issue: [],
            lesson: [],
            memory: [],
            note: [],
        };
        for (const d of source)
            out[d.type].push(d);
        return out;
    }
    async getGraph() {
        if (this.graphCache)
            return this.graphCache;
        const index = await this.get();
        this.graphCache = buildGraph(index);
        return this.graphCache;
    }
    async getSearchIndex() {
        if (this.searchCache)
            return this.searchCache;
        const index = await this.get();
        this.searchCache = buildInvertedIndex(index.entries);
        return this.searchCache;
    }
    async search(query, limit = 50) {
        const index = await this.get();
        const bm25 = await this.getSearchIndex();
        const ranked = searchBM25(bm25, query, limit);
        return ranked
            .map((r) => index.byId[r.docId])
            .filter((d) => Boolean(d));
    }
    // -------------------------------------------------------------------------
    // Walk
    // -------------------------------------------------------------------------
    async scanFiles() {
        const out = [];
        const singletons = [
            { rel: 'project.md', type: 'project' },
            { rel: 'roadmap.md', type: 'roadmap' },
        ];
        for (const s of singletons) {
            const entry = await this.parseFileEntry(join(this.workflowRoot, s.rel), s.type);
            if (entry)
                out.push(entry);
        }
        // specs/*.md
        for (const name of await safeReaddir(join(this.workflowRoot, 'specs'))) {
            if (extname(name).toLowerCase() !== '.md')
                continue;
            const entry = await this.parseFileEntry(join(this.workflowRoot, 'specs', name), 'spec');
            if (entry)
                out.push(entry);
        }
        // phases/NN-slug/*.md
        const phasesRoot = join(this.workflowRoot, 'phases');
        for (const phaseDir of await safeReaddir(phasesRoot)) {
            const abs = join(phasesRoot, phaseDir);
            let isDir = false;
            try {
                const s = await stat(abs);
                isDir = s.isDirectory();
            }
            catch {
                continue;
            }
            if (!isDir)
                continue;
            const phaseRef = parsePhaseRef(phaseDir);
            for (const name of await safeReaddir(abs)) {
                if (extname(name).toLowerCase() !== '.md')
                    continue;
                const entry = await this.parseFileEntry(join(abs, name), 'phase', { phaseRef });
                if (entry)
                    out.push(entry);
            }
        }
        // memory/*.md  (MEM-* → memory, TIP-* → note, others → memory)
        for (const name of await safeReaddir(join(this.workflowRoot, 'memory'))) {
            if (extname(name).toLowerCase() !== '.md')
                continue;
            const upper = name.toUpperCase();
            const type = upper.startsWith('TIP-') ? 'note' : 'memory';
            const entry = await this.parseFileEntry(join(this.workflowRoot, 'memory', name), type);
            if (entry)
                out.push(entry);
        }
        return out;
    }
    async scanVirtual() {
        const out = [];
        for (const name of await safeReaddir(join(this.workflowRoot, 'issues'))) {
            if (extname(name).toLowerCase() !== '.jsonl')
                continue;
            const abs = join(this.workflowRoot, 'issues', name);
            if (!this.isInsideRoot(abs))
                continue;
            const rel = toForwardSlash(relative(this.workflowRoot, abs));
            out.push(...(await loadVirtualEntries(abs, 'issue', rel)));
        }
        for (const name of await safeReaddir(join(this.workflowRoot, 'learning'))) {
            if (extname(name).toLowerCase() !== '.jsonl')
                continue;
            const abs = join(this.workflowRoot, 'learning', name);
            if (!this.isInsideRoot(abs))
                continue;
            const rel = toForwardSlash(relative(this.workflowRoot, abs));
            out.push(...(await loadVirtualEntries(abs, 'lesson', rel)));
        }
        return out;
    }
    async parseFileEntry(absPath, type, opts = {}) {
        if (!this.isInsideRoot(absPath))
            return null;
        try {
            const ls = await lstat(absPath);
            if (ls.isSymbolicLink())
                return null;
            if (!ls.isFile())
                return null;
        }
        catch {
            return null;
        }
        let raw;
        let stats;
        try {
            raw = await readFile(absPath, 'utf-8');
            stats = await stat(absPath);
        }
        catch {
            return null;
        }
        const { data, content } = parseFrontmatter(raw);
        const fileName = basename(absPath);
        const stem = basename(fileName, extname(fileName));
        const title = asString(data.title) || firstHeading(content) || stem;
        const summary = asString(data.summary) || firstParagraph(content);
        const tags = extractTags(data);
        const status = asStatus(data.status) ?? inferStatus(type);
        const related = normalizeRelated(data.related);
        const phaseRef = opts.phaseRef ?? parsePhaseRef(basename(dirname(absPath)));
        const ext = extractExt(data);
        const rel = toForwardSlash(relative(this.workflowRoot, absPath));
        // Memory/note files live under memory/ with MEM-<slug>.md or TIP-<slug>.md
        // naming. Strip the prefix from the id-generating stem so the id matches
        // what the WikiWriter produced at create time (`memory-<slug>`, `note-<slug>`).
        let idStem = stem;
        if (type === 'memory' && /^MEM-/i.test(stem))
            idStem = stem.slice(4);
        else if (type === 'note' && /^TIP-/i.test(stem))
            idStem = stem.slice(4);
        const id = `${type}-${slugify(idStem)}`;
        return {
            id,
            type,
            title,
            summary,
            tags,
            status,
            created: new Date(stats.birthtimeMs || stats.mtimeMs).toISOString(),
            updated: new Date(stats.mtimeMs).toISOString(),
            phaseRef: phaseRef ?? null,
            related,
            source: { kind: 'file', path: rel },
            body: content,
            ext,
        };
    }
    buildBacklinks(entries, byId) {
        const bl = {};
        const titleIndex = new Map();
        for (const d of entries)
            titleIndex.set(d.title.toLowerCase(), d.id);
        const push = (target, source) => {
            const resolved = resolveLink(target, byId, titleIndex);
            if (!resolved)
                return;
            if (!bl[resolved])
                bl[resolved] = [];
            if (!bl[resolved].includes(source))
                bl[resolved].push(source);
        };
        for (const d of entries) {
            for (const rel of d.related)
                push(rel, d.id);
            if (d.body) {
                const linkRe = /\[\[([^\]]+)\]\]/g;
                let m;
                while ((m = linkRe.exec(d.body)))
                    push(m[1], d.id);
            }
        }
        return bl;
    }
    isInsideRoot(absPath) {
        const requested = resolve(absPath);
        return requested === this.workflowRoot || requested.startsWith(this.workflowRoot + sep);
    }
}
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function asString(value) {
    return typeof value === 'string' ? value : '';
}
function asStatus(value) {
    const allowed = ['draft', 'active', 'completed', 'blocked', 'archived'];
    return typeof value === 'string' && allowed.includes(value)
        ? value
        : null;
}
function inferStatus(type) {
    if (type === 'spec' || type === 'project' || type === 'roadmap')
        return 'active';
    return 'draft';
}
function firstHeading(body) {
    const m = body.match(/^#\s+(.+)$/m);
    return m ? m[1].trim() : '';
}
function firstParagraph(body) {
    const withoutFm = body.replace(/^#\s+.+\n+/, '');
    const para = withoutFm.split(/\n\s*\n/).find((p) => p.trim().length > 0) ?? '';
    return para.trim().replace(/\s+/g, ' ').slice(0, 240);
}
function extractTags(data) {
    const tags = data.tags ?? data.keywords;
    if (!Array.isArray(tags))
        return [];
    return tags.map(String).filter((s) => s.length > 0);
}
function normalizeRelated(value) {
    if (!Array.isArray(value))
        return [];
    const out = [];
    for (const v of value) {
        if (typeof v !== 'string')
            continue;
        // Block-array parser keeps surrounding quotes; strip them so
        // `"[[id]]"` and `[[id]]` both resolve.
        const unquoted = v.replace(/^["']|["']$/g, '');
        const m = unquoted.match(/^\[\[([^\]]+)\]\]$/);
        out.push(m ? m[1] : unquoted);
    }
    return out;
}
function extractExt(data) {
    const known = new Set(['title', 'summary', 'tags', 'status', 'related']);
    const out = {};
    for (const [k, v] of Object.entries(data)) {
        if (!known.has(k))
            out[k] = v;
    }
    return out;
}
function parsePhaseRef(dirName) {
    const m = dirName.match(/^(\d+)-/);
    return m ? Number(m[1]) : null;
}
function slugify(input) {
    return input
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
}
function resolveLink(target, byId, titleIndex) {
    if (byId[target])
        return target;
    const hit = titleIndex.get(target.toLowerCase());
    return hit ?? null;
}
async function safeReaddir(dir) {
    try {
        return await readdir(dir);
    }
    catch {
        return [];
    }
}
export function filterEntries(entries, filters) {
    return entries.filter((d) => {
        if (filters.type && d.type !== filters.type)
            return false;
        if (filters.tag && !d.tags.includes(filters.tag))
            return false;
        if (filters.phase !== undefined && d.phaseRef !== filters.phase)
            return false;
        if (filters.status && d.status !== filters.status)
            return false;
        if (filters.q) {
            const q = filters.q.toLowerCase();
            if (!d.title.toLowerCase().includes(q) && !d.summary.toLowerCase().includes(q)) {
                return false;
            }
        }
        return true;
    });
}
//# sourceMappingURL=wiki-indexer.js.map