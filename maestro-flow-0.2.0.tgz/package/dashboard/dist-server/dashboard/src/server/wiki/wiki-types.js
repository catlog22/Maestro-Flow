export {};
//# sourceMappingURL=wiki-types.js.map