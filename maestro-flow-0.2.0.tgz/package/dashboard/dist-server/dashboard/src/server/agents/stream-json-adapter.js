// ---------------------------------------------------------------------------
// StreamJsonAdapter — shared adapter for Gemini CLI and Qwen CLI
// Both use the `-o stream-json` output protocol with identical message shapes.
// ---------------------------------------------------------------------------
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { BaseAgentAdapter } from './base-adapter.js';
import { EntryNormalizer } from './entry-normalizer.js';
import { loadEnvFile } from './env-file-loader.js';
import { StreamMonitor } from './stream-monitor.js';
import { cleanSpawnEnv } from './env-cleanup.js';
// ---------------------------------------------------------------------------
// Adapter implementation
// ---------------------------------------------------------------------------
export class StreamJsonAdapter extends BaseAgentAdapter {
    agentType;
    executable;
    childProcesses = new Map();
    readlineInterfaces = new Map();
    lastContentLength = new Map();
    toolIdNames = new Map();
    stoppedEmitted = new Set();
    streamMonitors = new Map();
    thinkingEmitted = new Set();
    constructor(executable, agentType) {
        super();
        this.executable = executable;
        this.agentType = agentType;
    }
    // --- Lifecycle hooks -----------------------------------------------------
    async doSpawn(processId, config) {
        const args = this.buildArgs(config);
        const [cmd, ...cmdArgs] = this.executable.split(/\s+/);
        const envFromFile = config.envFile ? loadEnvFile(config.envFile) : {};
        const envOverrides = { ...envFromFile, ...config.env };
        if (config.apiKey) {
            if (this.agentType === 'gemini') {
                envOverrides.GEMINI_API_KEY = config.apiKey;
            }
            else if (this.agentType === 'qwen') {
                envOverrides.DASHSCOPE_API_KEY = config.apiKey;
            }
        }
        const childEnv = cleanSpawnEnv(envOverrides);
        const child = spawn(cmd, [...cmdArgs, ...args], {
            cwd: config.workDir,
            env: childEnv,
            stdio: ['pipe', 'pipe', 'pipe'],
            shell: true,
            windowsHide: true,
        });
        if (!child.stdout || !child.stdin || !child.stderr) {
            throw new Error(`Failed to spawn ${this.agentType}: stdio streams not available`);
        }
        // Pipe prompt to stdin then close the write end
        child.stdin.write(config.prompt);
        child.stdin.end();
        // Heartbeat monitor: detect stale streams (60s silence)
        const monitor = new StreamMonitor(() => {
            this.emitEntry(processId, EntryNormalizer.error(processId, 'Stream stale: no output for 60s', 'stream_stale'));
        });
        this.streamMonitors.set(processId, monitor);
        // Line-by-line parsing of stream-json stdout
        const rl = createInterface({ input: child.stdout });
        rl.on('line', (line) => {
            monitor.heartbeat();
            this.parseStreamJsonMessage(line, processId);
        });
        // Stderr => error entries
        child.stderr.on('data', (chunk) => {
            const text = chunk.toString().trim();
            if (text.length > 0) {
                this.emitEntry(processId, EntryNormalizer.error(processId, text, 'stderr'));
            }
        });
        // Last-resort fallback: if stdout closes but neither 'exit' nor 'close'
        // fire on the child (Windows shell: true + npx process tree edge case),
        // emit stopped after a short delay to let the primary handlers run first.
        rl.on('close', () => {
            setTimeout(() => {
                this.emitStopped(processId, 'stdout closed (readline fallback)');
            }, 500);
        });
        // Process exit handling
        this.setupProcessListeners(child, processId);
        // Store references
        this.childProcesses.set(processId, child);
        this.readlineInterfaces.set(processId, rl);
        return {
            id: processId,
            type: this.agentType,
            status: 'running',
            config,
            startedAt: new Date().toISOString(),
            pid: child.pid,
        };
    }
    async doStop(processId) {
        const child = this.childProcesses.get(processId);
        if (!child) {
            return;
        }
        const proc = this.getProcess(processId);
        if (proc) {
            proc.status = 'stopping';
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopping', 'User requested stop'));
        }
        // Graceful SIGTERM
        child.kill('SIGTERM');
        // SIGKILL fallback after 5 seconds
        const killTimer = setTimeout(() => {
            if (!child.killed) {
                child.kill('SIGKILL');
            }
        }, 5000);
        child.once('exit', () => {
            clearTimeout(killTimer);
        });
        this.cleanup(processId);
    }
    async doSendMessage(processId, _content) {
        // Gemini/Qwen receive prompt via stdin at spawn time.
        // Follow-up messages are not supported in stream-json mode.
        throw new Error(`[${this.agentType}] Follow-up messages are not supported in stream-json mode`);
    }
    async doRespondApproval(_decision) {
        // Gemini/Qwen handle approvals via --approval-mode flag, not stdin.
        // No-op.
    }
    // --- Stream-json parsing -------------------------------------------------
    parseStreamJsonMessage(line, processId) {
        const trimmed = line.trim();
        if (trimmed.length === 0) {
            return;
        }
        let msg;
        try {
            msg = JSON.parse(trimmed);
        }
        catch {
            // Non-JSON lines (e.g. npx bootstrap output) are silently skipped
            return;
        }
        if (!msg || typeof msg !== 'object' || !('type' in msg)) {
            return;
        }
        switch (msg.type) {
            case 'init': {
                this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'running', 'Session started'));
                break;
            }
            case 'message': {
                this.handleMessageEntry(msg, processId);
                break;
            }
            case 'tool_use': {
                const name = msg.tool_name ?? msg.name ?? 'unknown';
                const input = msg.parameters ?? msg.input ?? {};
                this.emitEntry(processId, EntryNormalizer.toolUse(processId, name, input, 'running'));
                // Track tool_id → name mapping for tool_result correlation
                if (msg.tool_id) {
                    this.toolIdNames.set(msg.tool_id, name);
                }
                break;
            }
            case 'tool_result': {
                const name = msg.tool_id
                    ? (this.toolIdNames.get(msg.tool_id) ?? msg.name ?? 'unknown')
                    : (msg.name ?? 'unknown');
                const isError = msg.is_error || (msg.status !== undefined && msg.status !== 'success');
                const status = isError ? 'failed' : 'completed';
                const content = msg.content ?? msg.output;
                this.emitEntry(processId, EntryNormalizer.toolUse(processId, name, {}, status, content));
                break;
            }
            case 'result': {
                const usage = msg.usage ?? msg.stats;
                if (usage) {
                    this.emitEntry(processId, EntryNormalizer.tokenUsage(processId, usage.input_tokens ?? 0, usage.output_tokens ?? 0));
                }
                break;
            }
            default:
                break;
        }
    }
    handleMessageEntry(msg, processId) {
        let content = msg.content ?? '';
        // Think tag extraction: strip <think> blocks, emit as separate thinking entries
        if (content.includes('<think>')) {
            if (content.includes('</think>')) {
                const thinkMatch = content.match(/<think>([\s\S]*?)<\/think>/);
                if (thinkMatch && !this.thinkingEmitted.has(processId)) {
                    const thought = thinkMatch[1].trim();
                    if (thought.length > 0) {
                        this.emitEntry(processId, EntryNormalizer.thinking(processId, thought));
                    }
                    this.thinkingEmitted.add(processId);
                }
                content = content.replace(/<think>[\s\S]*?<\/think>/, '').trimStart();
            }
            else {
                // Incomplete think tag — wait for closing tag in next cumulative chunk
                return;
            }
        }
        if (msg.delta) {
            // Cumulative-to-delta conversion: stream-json sends cumulative text
            const lastLen = this.lastContentLength.get(processId) ?? 0;
            const delta = content.slice(lastLen);
            this.lastContentLength.set(processId, content.length);
            if (delta.length > 0) {
                this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, delta, true));
            }
        }
        else {
            // Complete message — reset cumulative tracker and emit full content
            this.lastContentLength.delete(processId);
            if (content.length > 0) {
                this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, content, false));
            }
        }
    }
    // --- Helpers -------------------------------------------------------------
    buildArgs(config) {
        const args = ['-o', 'stream-json'];
        if (config.model) {
            args.push('-m', config.model);
        }
        if (config.approvalMode === 'auto') {
            args.push('--approval-mode', 'yolo');
        }
        return args;
    }
    emitStopped(processId, reason) {
        if (this.stoppedEmitted.has(processId))
            return;
        this.stoppedEmitted.add(processId);
        this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopped', reason));
        const proc = this.getProcess(processId);
        if (proc) {
            proc.status = 'stopped';
        }
        this.cleanup(processId);
        this.removeProcess(processId);
    }
    setupProcessListeners(child, processId) {
        child.on('exit', (code, signal) => {
            const reason = signal
                ? `Terminated by signal: ${signal}`
                : `Exited with code: ${code ?? 'unknown'}`;
            this.emitStopped(processId, reason);
        });
        // Fallback: 'close' fires after exit + stdio close — covers edge cases
        // where 'exit' is missed on Windows process trees (shell: true + npx).
        child.on('close', (code, signal) => {
            const reason = signal
                ? `Terminated by signal: ${signal}`
                : `Exited with code: ${code ?? 'unknown'}`;
            this.emitStopped(processId, reason);
        });
        child.on('error', (err) => {
            this.emitEntry(processId, EntryNormalizer.error(processId, err.message, 'spawn_error'));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'error';
            }
        });
    }
    cleanup(processId) {
        const rl = this.readlineInterfaces.get(processId);
        if (rl) {
            rl.close();
            this.readlineInterfaces.delete(processId);
        }
        const monitor = this.streamMonitors.get(processId);
        if (monitor) {
            monitor.dispose();
            this.streamMonitors.delete(processId);
        }
        this.childProcesses.delete(processId);
        this.lastContentLength.delete(processId);
        this.thinkingEmitted.delete(processId);
        this.toolIdNames.clear();
        // Note: stoppedEmitted is intentionally NOT cleared here — it must persist
        // to guard against the readline close fallback timer firing after cleanup.
    }
}
//# sourceMappingURL=stream-json-adapter.js.map