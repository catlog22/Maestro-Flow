// ---------------------------------------------------------------------------
// DispatchStrategy — pluggable interface for issue selection in tick loop
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=dispatch-strategy.js.map